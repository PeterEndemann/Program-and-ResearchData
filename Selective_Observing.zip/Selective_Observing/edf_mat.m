clear all
close all
%% load

R=Edf2Mat('PD_1_1.edf',true)
save(R)

