%% analise
clear all
close all
format short g
num_part = 5;
%% ------------------------------------------------------------[Tabela]
for n = 1 : num_part
    load(sprintf('P%d',n))
    eval(sprintf('P = P%d;',n))
    tab(n).participante = sprintf('P%d',n);
    tab(n).comp_F1 = length(P.Resp.p1) * 2;
    tab(n).ind_F1 = (P.Resp.p1(end-11 : end) / (P.Resp.p1(end-11 : end) + P.Resp.p2(end-11 : end))) * 100;
    tab(n).comp_F2 = length(P.Resp.p3) * 2;
    tab(n).ind_F2 = (P.Resp.p3(end-11 : end) / (P.Resp.p3(end-11 : end) + P.Resp.p4(end-11 : end))) * 100;
    tab(n).comp_F3 = length(P.Resp.p5) * 2;
    tab(n).ind_F3 = (P.Resp.p5(end-11 : end) / (P.Resp.p5(end-11 : end) + P.Resp.p6(end-11 : end))) * 100;
end

tab_res = struct2table(tab)

T =[];
%% --------------------------------------------------------[ocular]
for n = 1 : num_part
    eval(sprintf('P = P%d;',n))
    
    for nn = 1 : length(P.Dur)
        eval(sprintf('idur_P%d(nn, 1) =  P.Dur(nn, 1) / (P.Dur(nn, 1) + P.Dur(nn, 2));',n))
        eval(sprintf('idur_P%d(nn, 2) =  P.Dur(nn, 3) / (P.Dur(nn, 3) + P.Dur(nn, 4));',n))
        eval(sprintf('idur_P%d(nn, 3) =  P.Dur(nn, 5) / (P.Dur(nn, 5) + P.Dur(nn, 6));',n))
        eval(sprintf('dur_P%d(nn, 1) =  P.Dur(nn, 1) / P.Dur(nn, 2);',n))
        eval(sprintf('dur_P%d(nn, 2) =  P.Dur(nn, 3) / P.Dur(nn, 4);',n))
        eval(sprintf('dur_P%d(nn, 3) =  P.Dur(nn, 5) / P.Dur(nn, 6);',n))
        
    end
    eval(sprintf('med(n,:) = mean (dur_P%d);',n))
    T = [T; [P.Dur(:, 1) P.Dur(:, 2)]];
    T = [T; [P.Dur(:, 3) P.Dur(:, 4)]];
    T = [T; [P.Dur(:, 5) P.Dur(:, 6)]];
    for tt = 1:length(T)
        T(tt, 3) = T(tt,1)/ T(tt,2);
        T(tt, 4) = T(tt,1)/ (T(tt,1)+ T(tt,2));
    end
    eval(sprintf('Tp%d = T;',n))
    T = [];
end


plot(mean(med),'Ok','LineWidth',3)
hold on
    line([0 4],[1 1],'LineWidth',3)
axis([0 4 0 3])