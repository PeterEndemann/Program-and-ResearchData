function T=variaveis_PD

%% textos
txt.t0='_ Bem-vindo! _';
txt.t20='Este experimento � composto por 3 fases. \n \n A passagem pelas fases depender� do seu desempenho.\n \n  Na tela ser�o apresentados quatro c�rculos. \n Voc� poder� olhar para eles livremente. \n Algum destes c�rculos poder� lhe passar informa��es relevantes.  \n \n Ao longo da tarefa voc� poder� ganhar pontos apertando livremente a barra de espa�o.  \n Em alguns momentos, Voc� ir� ganhar e acumular pontos.  \n Um som indicar� quando um ponto for ganho.  \n  \n Seu objetivo � ganhar o maior n�mero de pontos, da forma mais eficiente poss�vel e chegar ao final da fase 3.';
txt.t10='Leia as Instru��es abaixo e quando estiver pronto, clique em qualquer tecla para come�ar!';

txt.t1='Vamos para a primeira fase! \n Quando estiver pronto, clique em qualquer tecla para come�ar \n \n \n Lembre-se, voc� deve ganhar e acumular o maior n�mero de pontos poss�veis \n e chegar no final dessa fase para avan�ar no experimento \n \n Obtenha informa��es olhando � vontade para o que tem atr�s dos c�rculos \n e ganho os pontos da formais eficiente poss�vel!!';  
txt.t2='Muito bom! \n \n Agora continue a ganhar o m�ximo de pontos poss�veis!!';
txt.t3='Vamos para �ltima etapa da primera fase! \n \n Essa etapa � semelhante � primeira. \n \n Ganhe o m�ximo de pontos da forma mais eficiente poss�vel ';
txt.t4='Parab�ns! Voc� passou para a fase 2 do experimento! \n \n Haver� uma simples diferen�a nessa fase. Em alguns momentos, os c�rculos ir�o se fechar. Para ter acesso �s informa��es novamente, \n voc� dever� olhar para o centro da tela, onde haver� um pequeno c�rculo. \n \n \n \n Voc� est� indo bem, continue assim!';
txt.t5='Muito bom! \n \n Agora continue a ganhar o m�ximo de pontos poss�veis!!';
txt.t6='Vamos para �ltima etapa da segunda fase! \n \n Essa etapa � semelhante � primeira. \n \n Ganhe o m�ximo de pontos da forma mais eficiente poss�vel ';
txt.t7='Parab�ns! Voc� ir� come�a a a terceira e �ltmia fase do experimento! \n \n  \n \n \n \n \n Seu objetivo continua o mesmo. \n \n Ganhe o m�ximo de pontos da forma mais eficiente poss�vel!';
T.txt=txt;
