function [largura_texto]=instrucao(fase,teste,Xc,Yc,txt,window)

largura_texto=109;
tamanho_letra=30;
%%
if teste==0
    switch fase
        case 1
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t1, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 2
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t2, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 3
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t3, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                 Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 4
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t4, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 5
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t5, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 6
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t6, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                 Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
        case 7
            start = 1;
            while start
                Screen ('TextSize',window,tamanho_letra);
                Screen ('TextFont',window,'Arial');
                DrawFormattedText(window,T.txt.t7, 'center' , 'center' , [240 240 240], largura_texto,[],[],1.63);
                Screen('Flip', window);
                [keyIsDown, secs, keyCode] = KbCheck;
                KD=keyIsDown;
                if KD>0
                    start = 0;
                end
            end
    end
    WaitSecs(0.5)
    Screen('Flip', window);
    WaitSecs(0.5)
end
end

